<?php
    header('Location: Login/index.php');

?>